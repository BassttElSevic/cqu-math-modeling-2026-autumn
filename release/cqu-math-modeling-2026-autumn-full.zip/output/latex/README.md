# 2020 ICM E题，2017963队：中文全译本

原件：工作区根目录 `13.pdf`，21个物理页（摘要页 + 正文页码1—20）。

本项目使用 LaTeX 重排摘要、目录、正文第1—8章、8幅图、5张表和26条参考文献。中文内容根据英文原文逐段翻译；用户提供的中文概述仅作为理解参考，未替换英文正文。参考文献保留英文题名、作者、年份、刊名和原始URL，同时增加中文译题。

## 文件与编译

- `main.tex`：主入口。
- `summary.tex`、`introduction.tex`、`models.tex`、`policy.tex`、`references.tex`：全文译稿。
- `figures/`：8幅图的LaTeX排版代码。
- `assets/`：从原件提取的图形素材与裁剪图。

常规环境使用 TeX Live / MiKTeX 的 XeLaTeX，安装 CTeX、TikZ、amsmath、booktabs、tabularx、enumitem、caption、fancyhdr、lastpage、xurl 等宏包，并准备宋体、微软雅黑、Times New Roman、Arial 字体。

```powershell
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

也可用 `latexmk -xelatex main.tex`。中文字体在 `main.tex` 导言区设置；其他操作系统可替换为本机的思源宋体/思源黑体等字体。中文自动分页，与英文版页码不强制一一对应。

## 图形处理

- 图1、2、5、8使用TikZ重建结构、图内文字和配色，保持原图关系、指标顺序与时间节点。
- 图3保留原图柱形、坐标和颜色，国家名称由LaTeX覆盖为中文。
- 图4保留原图柱形、坐标、指标缩写，图例由LaTeX覆盖为中文。
- 图6直接保留原文海龟插图。
- 图7保留原PDF曲线、坐标、箭头和数据标注，用LaTeX替换英文说明；未以自造数据重拟合曲线。
- 正文、公式和表格均为可选择文字及LaTeX原生排版。

## 核对与译注

原文的观点、数值和不一致均保留，必要处用“译注”与正文隔离。特别注明了负向标准化公式、表4重复列标题、PMC31命名、权重和、两表PMC差异、21.9%比较基期、背景数量级、人均106千克的比较口径，以及图8与备忘录10%指标口径的差异。译注不构成对原论文数据的重新估计。

全文翻译完成后，独立子agent逐段对照英文正文、公式和参考文献，随后主agent落实审校修改；另对最终PDF进行渲染及结构检查。详细记录见交付目录中的《翻译与排版校验说明.md》。

## 在线核对依据（访问日期：2026-11-07）

1. [国家标准官方条目：GB/T 7713.2-2022《学术论文编写规则》](https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=0B963916637B8F34B295FCF4A51A1BE5)。作为中文论文体例、图表及符号排版的参考；本译本优先保留原文的竞赛摘要页和章节结构。
2. [CTAN：CTeX](https://ctan.org/pkg/ctex) 与 [xeCJK官方文档](https://tug.ctan.org/macros/xetex/latex/xecjk/xeCJK.pdf)。核对中文字体、标点和中西文间距的排版方案。
3. [UNDP《2020年人类发展报告》中文版](https://hdr.undp.org/system/files/documents/hdr2020cn.pdf)。核对“人类发展指数（HDI）”中文术语。
4. [《系统工程理论与实践》2009年第29卷第10期目录](https://sysengi.cjoe.ac.cn/CN/Y2009/V29/I10)。核对文献26中文题名《无偏灰色Verhulst模型及其应用》及模型名称。
5. [生态环境部：生活垃圾焚烧污染控制标准](https://www.mee.gov.cn/ywgz/fgbz/bz/bzwb/gthw/gtfwwrkzbz/201405/t20140530_276307.shtml)。核对焚烧、排放控制等中文术语；未把中国排放限值代入原论文。
6. [Geyer等（2017）原研究全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC5517107/)。核对引言累计塑料生产量和废物量的数量级译注。
